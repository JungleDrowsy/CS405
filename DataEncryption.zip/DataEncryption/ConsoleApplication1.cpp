#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// Encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">Input string to process</param>
/// <param name="key">Key to use in encryption / decryption</param>
/// <returns>Transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key) {
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Ensure valid input
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // XOR each character with the corresponding key character
    for (size_t i = 0; i < source_length; ++i) {
        output[i] = source[i] ^ key[i % key_length];
    }

    // Verify output length
    assert(output.length() == source_length);

    return output;
}

/// <summary>
/// Load data from a file into a string
/// </summary>
/// <param name="filename">File to read</param>
/// <returns>File content as a string</returns>
std::string read_file(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return "";
    }

    std::stringstream buffer;
    buffer << file.rdbuf(); // Read entire file content
    return buffer.str();
}

/// <summary>
/// Extract student name from the file data
/// </summary>
/// <param name="string_data">File content</param>
/// <returns>Student name</returns>
std::string get_student_name(const std::string& string_data) {
    std::string student_name;
    size_t pos = string_data.find('\n'); // Find the first newline
    if (pos != std::string::npos) {
        student_name = string_data.substr(0, pos);
    }
    return student_name;
}

/// <summary>
/// Save encrypted/decrypted data to a file
/// </summary>
/// <param name="filename">File to save</param>
/// <param name="student_name">Student name</param>
/// <param name="key">Encryption key</param>
/// <param name="data">Data to save</param>
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }

    // Get current date
    std::time_t now = std::time(nullptr);
    std::tm tm;  // Declare a tm structure
    if (localtime_s(&tm, &now) != 0) {
        std::cerr << "Error converting time." << std::endl;
        return;
    }

    char timestamp[20];  // Buffer to store the formatted timestamp
    std::strftime(timestamp, sizeof(timestamp), "%Y-%m-%d", &tm);  // Pass the address of tm

    // Write data to file
    file << student_name << "\n"   // Line 1: Student name
        << timestamp << "\n"      // Line 2: Timestamp
        << key << "\n"            // Line 3: Key
        << data << "\n";          // Line 4+: Data
}

int main() {
    std::cout << "Encryption Decryption Test!" << std::endl;

    // File names
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";

    // Read the input file
    const std::string source_string = read_file(file_name);
    if (source_string.empty()) {
        std::cerr << "Failed to read input file." << std::endl;
        return 1;
    }

    // Encryption key
    const std::string key = "password";

    // Get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // Encrypt the source string
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save the encrypted data to a file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt the encrypted string
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save the decrypted data to a file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;
}