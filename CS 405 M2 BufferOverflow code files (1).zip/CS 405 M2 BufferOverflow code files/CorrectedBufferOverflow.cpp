
// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <limits> // Required for numeric_limits

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // The account_number remains constant and directly before the user_input buffer.
    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value (max 19 characters): ";
    std::cin.getline(user_input, sizeof(user_input)); // Safely read input into the buffer.

    // Check if the user attempted to input too many characters
    if (std::cin.fail()) {
        std::cin.clear(); // Clear the error flag
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard remaining input
        std::cout << "Error: Input exceeded maximum allowed length of 19 characters." << std::endl;
    } else {
        std::cout << "You entered: " << user_input << std::endl;
    }

    std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
